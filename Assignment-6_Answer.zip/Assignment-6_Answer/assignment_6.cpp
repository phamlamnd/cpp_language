#include <iostream>

using namespace std;

class String
{
public:
    String();
    String( const char *value ); // nhap chuoi
    ~String(); // xoa chuoi

    String operator+( String &strings ); // ghep chuoi
    void reverse(); // dao nguoc chuoi
    int size(); // tinh do dai
    int compare( String &destString ); // so sanh chuoi
    /*
     0: They compare equal
     < 0: Either the value of the first character that does not match is lower in the compared string, or all compared characters match but the compared string is shorter.
     > 0: Either the value of the first character that does not match is greater in the compared string, or all compared characters match but the compared string is longer.
    */
    void print();
    char *value();

private:
    char *m_value;
};

String::String()
{
    m_value = NULL;
}

String::String( const char *value )
{
    int inputLength = strlen( value );
    m_value = new char( inputLength + 1 );

    strcpy( m_value, value );
}

String::~String()
{
    if( NULL != m_value )
    {
        delete m_value;
    }
}

String String::operator+( String &strings )
{
    int length = this->size() + strings.size();
    char *strTemp = new char( length + 1 );
    if( NULL != m_value )
    {
        strcat( strTemp, m_value );
    }

    strcat( strTemp, strings.value() );

    String ret( strTemp );

    return ret;
}

int String::size()
{
    return strlen( m_value );
}

char * String::value()
{
    return m_value;
}

int String::compare( String &destString )
{
    if( strlen( m_value ) > strlen( destString.value() ) )
    {
        return 1;
    }
    else if( strlen( m_value ) < strlen( destString.value() ) ) {
        return -1;
    }
    else
    {
        for( int i = 0; i < this->size(); i++ )
        {
            if( m_value[i] > destString.value()[i] )
                return 1;
            if( m_value[i] < destString.value()[i] )
                return -1;
        }

        return 0;
    }
}

void String::print()
{
    cout << m_value << endl;
}

void String::reverse()
{
    int len = strlen( m_value );
    for(int i = 0; i < len / 2; i++)
    {
        char temp = m_value[i];
        m_value[i] = m_value[len - i - 1];
        m_value[len - i - 1] = temp;
    }
}

int main(int argc, char const *argv[])
{
    // khoi tao
    String string1( "abc" );
    String string2( "xyz" );

    String string3;

    // test cong chuoi
    string3 = string1 + string2;

    // in thong tin
    cout << "string1: "; string1.print();
    cout << "string2: "; string2.print();
    cout << "string3: "; string3.print();

    // test dao nguoc chuoi
    string3.reverse(); string3.print();

    // test so sanh chuoi
    if( string1.compare( string2 ) > 0 )
    {
        cout << "string1 > string2" << endl;
    }
    else if( string1.compare( string2 ) < 0 )
    {
        cout << "string1 < string2" << endl;
    }
    else
    {
        cout << "string1 = string2" << endl;
    }

    return 0;
}
